SELECT * FROM Employee;

SELECT * FROM profEmp;

SELECT * FROM Resident;

SELECT * FROM polEmp;

SELECT * FROM Member;

SELECT * FROM Chairman;

SELECT * FROM Budget;

SELECT * FROM Source;

SELECT * FROM Collection;

SELECT * FROM GovFund;

SELECT * FROM Taxes;

SELECT * FROM Donor;

SELECT * FROM Inspector;

SELECT * FROM Committee;

SELECT * FROM Institution;

SELECT * FROM Donation;

SELECT * FROM Fines;

SELECT * FROM Inquiries;

SELECT * FROM memberAt;

SELECT * FROM Finance;
